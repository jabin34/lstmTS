//#include "common/LteControlInfo.h"
//#include "stack/phy/ChannelModel/LteChannelModel.h"
//#include <assert.h>
//#include <inet/common/INETDefs.h>
//#include <ctime>
//#include <vector>
//#include <numeric>
//#ifndef STACK_PHY_LAYER_CALPARAMETER_H_
//#define STACK_PHY_LAYER_CALPARAMETER_H_
//
//
//class calParameter {
//public:
//    calParameter();
//    virtual ~calParameter();
//
//     static const int NUM_TOWERS = 4;
//        double bsLoad[NUM_TOWERS] = {0};
//        double towerLoad_global = 0;
//        // Add variables to store predicted loads
//            //double predictedLoad4G_global;
//           //double predictedLoad5G_global;
//        double prediction_4g; // Store prediction
//            double prediction_5g; // Store prediction
//            double getPrediction4G() const { return prediction_4g; } // Getter
//             double getPrediction5G() const { return prediction_5g; } // Getter
//     double calculateEachTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame);
////    void calculateTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame);
////    double towerLoad(LteAirFrame* frame, UserControlInfo* lteInfo);
//    double getDoubleValueFile(std::string filepath);
//   // void calculateTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame);
//    void runGPR();
//    void runLSTM();
//   // void runLSTM();
//   // void saveArrayToFile(const std::string& fileName, const std::vector<double>& array);
//  //  double getParfromFile(std::string filepath) ;
//    //double towerLoad(LteAirFrame* frame, UserControlInfo* lteInfo);
//
//};
//
//#endif

//#ifndef STACK_PHY_LAYER_CALPARAMETER_H_
//#define STACK_PHY_LAYER_CALPARAMETER_H_
//
//#include "common/LteControlInfo.h"
//#include "stack/phy/ChannelModel/LteChannelModel.h"
//#include <assert.h>
//#include <inet/common/INETDefs.h>
//#include <ctime>
//#include <vector>
//#include <numeric>
//#include <deque>
//#include <map>
//
//class calParameter {
//public:
//    calParameter();
//    virtual ~calParameter();
//
//    static const int NUM_TOWERS = 4;
//    static const int N_STEPS = 5; // Reduced for faster training
//    double bsLoad[NUM_TOWERS] = {0};
//    double towerLoad_global = 0;
//    double prediction_4g;
//    double prediction_5g;
//
//    // In-memory storage for tower loads
//    std::map<MacNodeId, std::deque<double>> towerLoads4G;
//    std::map<MacNodeId, std::deque<double>> towerLoads5G;
//
//    // Methods for managing tower loads
//    void addTowerLoad(MacNodeId towerId, bool is5G, double load);
//    void saveTowerLoadsToFile(const std::string& filename);
//
//    double getPrediction4G() const { return prediction_4g; }
//    double getPrediction5G() const { return prediction_5g; }
//    double calculateEachTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame);
//    void runGPR();
//    void runLSTM();
//    double getDoubleValueFile(std::string filepath);
//};
//
//#endif


#ifndef _CALPARAMETER_H_
#define _CALPARAMETER_H_

#include "common/LteControlInfo.h"
#include "stack/phy/packet/LteAirFrame.h"
#include <vector>
#include <string>

#define NUM_TOWERS 4

class calParameter {
public:
    calParameter();
    virtual ~calParameter() {}

    double bsLoad[NUM_TOWERS];
    double towerLoad_global;
    double prediction_4g;
    double prediction_5g;

    double getPrediction4G() const { return prediction_4g; }
    double getPrediction5G() const { return prediction_5g; }
    double calculateEachTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame);
    void runGPR();
    void runLSTM();
    double getDoubleValueFile(std::string filepath);

private:
    std::string baseFilePath;
};

#endif

