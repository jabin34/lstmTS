//#include <assert.h>
//#include "stack/phy/layer/LtePhyUe.h"
//#include <ctime>
//#include <vector>
//#include <numeric>
//#include <iostream>
//#include <cmath>
//#include "calParameter.h"
//
//
//
//std::string baseFilePath ="/home/israt/OMNETPP/ts/simu5G/src/data/";
//double bsLoadCal1Weighted;
//const int NUM_TOWERS = 4;
//double bsLoad[NUM_TOWERS] = {0};  // Use an array to store bsLoad values
//double bsLoadCal1[NUM_TOWERS] = {0};
//double minLoad = -4;
//double minTowerLoad, avgLoad, sumbsLoadCal1, towerCount;
//double towerLoad_cur_simtime = 0, eachTowerLoad_cur_simtime = 0;
//
//calParameter::calParameter()
//{
//    //constructor
//}
//calParameter::~calParameter()
//{
//    //destructor
//}
//
//double calParameter::calculateEachTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame)
//{
//    int index = lteInfo->getSourceId()-1;
////    std::cout << "TowerId: " << index + 1 << endl;
//
////    int totalVehicles = 10;
//    int totalVehicles = (int)getDoubleValueFile(baseFilePath+"nodeCount.txt");
////    std::cout << "totalVehicles: " << totalVehicles << endl;
//    if (bsLoad[index]<totalVehicles)
//        bsLoad[index]++;
////    std::cout << "Tower Load (bsLoad): " << bsLoad[index] << endl;
//
//    bsLoadCal1Weighted = (bsLoad[index] + 4) / (std::accumulate(bsLoad, bsLoad + NUM_TOWERS, 0) + 4);
////    if (simTime().dbl() != eachTowerLoad_cur_simtime)
//    if((int)simTime().dbl() % 3 == 0)
//    {
//        bsLoad[index] = {0};
//        bsLoadCal1Weighted = 0;
////        eachTowerLoad_cur_simtime = simTime().dbl();
//    }
//    towerLoad_global = bsLoadCal1Weighted;
//    return bsLoadCal1Weighted;
//}
//
//
//void calParameter::runGPR() {
//    std::string pypredGPRFile;
//    std::string pypredGPR_CmdPyCpp = "python3 " + baseFilePath + "gRP.py";
//    pypredGPR_CmdPyCpp += pypredGPRFile;
//    system(pypredGPR_CmdPyCpp.c_str());
//}
//
//double calParameter::getDoubleValueFile(std::string filepath)
//{
//    std::ifstream file(filepath);
//    std::string valueData;
//    double valueDouble = 0;
//    while (std::getline (file, valueData))
//    {
//        valueDouble = atof(valueData.c_str());
//    }
//    file.close();
//    return valueDouble;
//}
//
//
//void calParameter::runLSTM() {
//    std::string lstmScriptPath = baseFilePath + "lstm.py";
//    std::string lstmCmd = "python3 " + lstmScriptPath;
//    std::cout << "Executing LSTM script: " << lstmCmd << std::endl;
//    int result = system(lstmCmd.c_str());
//    if (result != 0) {
//        std::cerr << "Error: Failed to execute LSTM script!" << std::endl;
//        prediction_4g = 0.1; // Fallback
//        prediction_5g = 0.1; // Fallback
//        return;
//    }
//
//    // Read predictions once after running the script
//    std::ifstream inFile4g(baseFilePath + "outputLSTM_4G.txt");
//    if (inFile4g.is_open()) {
//        std::string line;
//        if (std::getline(inFile4g, line)) {
//            prediction_4g = std::stod(line);
//        }
//        inFile4g.close();
//    }
//
//    std::ifstream inFile5g(baseFilePath + "outputLSTM_5G.txt");
//    if (inFile5g.is_open()) {
//        std::string line;
//        if (std::getline(inFile5g, line)) {
//            prediction_5g = std::stod(line);
//        }
//        inFile5g.close();
//    }
//}



#include "stack/phy/layer/calParameter.h"
#include <fstream>
#include <numeric>
#include <iostream>
#include <cstdlib>

calParameter::calParameter() : prediction_4g(0.1), prediction_5g(0.1) {
    baseFilePath = "/home/israt/OMNETPP/ts/simu5G/src/data/";
    for (int i = 0; i < NUM_TOWERS; ++i) {
        bsLoad[i] = 0;
    }
}

double calParameter::calculateEachTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame) {
    int index = lteInfo->getSourceId() - 1;
    int totalVehicles = (int)getDoubleValueFile(baseFilePath + "nodeCount.txt");
    if (bsLoad[index] < totalVehicles) {
        bsLoad[index]++;
    }
    double sumBsLoad = std::accumulate(bsLoad, bsLoad + NUM_TOWERS, 0.0);
    double bsLoadCal1Weighted = (bsLoad[index] + 4) / (sumBsLoad + 4);
    if ((int)omnetpp::simTime().dbl() % 3 == 0) {
        bsLoad[index] = 0;
        bsLoadCal1Weighted = 0;
    }
    towerLoad_global = bsLoadCal1Weighted;

    // Save load to file for LSTM
    std::ofstream outFile(baseFilePath + "tower_Load_test.txt", std::ios::app);
    if (outFile.is_open()) {
        outFile << omnetpp::simTime().dbl() << "," << (index + 1) << ","
                << (index < 2 ? 0 : 1) << "," << bsLoadCal1Weighted << "\n";
        outFile.close();
    }

    return bsLoadCal1Weighted;
}

void calParameter::runLSTM() {
    std::string lstmScriptPath = baseFilePath + "lstm.py";
    std::string lstmCmd = "python3 " + lstmScriptPath;
    std::cout << "Executing LSTM script: " << lstmCmd << std::endl;
    int result = system(lstmCmd.c_str());
    if (result != 0) {
        std::cerr << "Error: Failed to execute LSTM script!" << std::endl;
        prediction_4g = 0.1;
        prediction_5g = 0.1;
        return;
    }

    std::ifstream inFile4g(baseFilePath + "outputLSTM_4G.txt");
    if (inFile4g.is_open()) {
        std::string line;
        if (std::getline(inFile4g, line)) {
            prediction_4g = std::stod(line);
        }
        inFile4g.close();
    }

    std::ifstream inFile5g(baseFilePath + "outputLSTM_5G.txt");
    if (inFile5g.is_open()) {
        std::string line;
        if (std::getline(inFile5g, line)) {
            prediction_5g = std::stod(line);
        }
        inFile5g.close();
    }

    std::cout << "LSTM Predictions - 4G: " << prediction_4g << ", 5G: " << prediction_5g
              << " at simTime: " << omnetpp::simTime().dbl() << std::endl;
}

void calParameter::runGPR() {
    std::string pypredGPRFile;
    std::string pypredGPR_CmdPyCpp = "python3 " + baseFilePath + "gRP.py " + pypredGPRFile;
    int result = system(pypredGPR_CmdPyCpp.c_str());
    if (result != 0) {
        std::cerr << "Warning: GPR script execution failed" << std::endl;
    }
}

double calParameter::getDoubleValueFile(std::string filepath) {
    std::ifstream file(filepath);
    std::string valueData;
    double valueDouble = 0;
    while (std::getline(file, valueData)) {
        valueDouble = atof(valueData.c_str());
    }
    file.close();
    return valueDouble;
}
