#ifndef _LTE_AIRPHYUE_H_
#define _LTE_AIRPHYUE_H_

#include "stack/phy/layer/LtePhyBase.h"
#include "stack/phy/das/DasFilter.h"
#include "stack/mac/layer/LteMacUe.h"
#include "stack/rlc/um/LteRlcUm.h"
#include "stack/pdcp_rrc/layer/LtePdcpRrc.h"
#include "stack/phy/layer/calParameter.h"
#include <random>
#include <vector> // NEW: For rssiHistory vector

// NEW: Define TowerLoadEntry struct
struct TowerLoadEntry {
    double time;
    MacNodeId towerId;
    bool is5G;
    double load;
};

struct NearestTowerInfo {
    MacNodeId towerIdX;      // Tower closest in x
    MacNodeId towerIdY;      // Tower closest in y
    double minDistX;         // Min x distance
    double minDistY;         // Min y distance
    MacNodeId closestTower;  // Single closest tower (Euclidean)
    double minDist;          // Min Euclidean distance
    bool is5G;               // True if closestTower is 5G (gNB), false if 4G (eNB)
};

// NEW: Structure to store RSSI history
struct RSSIEntry {
    double time;
    int nodeId;
    int towerId;
    double rssi;
};

class DasFilter;

class LtePhyUe : public LtePhyBase
{
public:
    // Other public methods...
    std::ofstream towerLoadFile;
    simtime_t lastLogTime;        // Track last logging time
    double prediction_4g;         // Predicted 4G load
    double prediction_5g;         // Predicted 5G load
    double lastLstmCallTime;

    void storeRSSIToFile(int nodeId, int towerId, double rssi);
    void redirectToNetwork(int nodeId, int towerId, double rssi);

    bool getSteeringDecision() const {
        return (prediction_5g < prediction_4g);  // true for 5G, false for 4G
    }

    std::vector<double> inputLSTMDataArray_tl; // Training data for LSTM
    std::vector<double> inputLSTMTestDataArray_tl; // Test data for LSTM
    double predScaValLSTM_tl; // Predicted scalar value from LSTM
    double lstmSimTime; // Last time LSTM was run
    std::set<int> proActTowSet;

protected:
    // NEW: RSSI history vector
    std::vector<RSSIEntry> rssiHistory;

    // NEW: SARSA variables
    std::map<MacNodeId, std::map<std::pair<int, int>, double>> Q_per_vehicle; // Q-table per vehicle
    std::vector<TowerLoadEntry> towerLoadData; // Store recent tower loads
    int curRAT; // Current RAT (0=5G, 1=4G)
    int prevRAT; // Previous RAT
    int tsDecision; // Traffic steering decision
    std::default_random_engine rng; // Random number generator

    // NEW: SARSA method declarations
    int selectRATAction(int state, double epsilon);
    int getNextState(int state, int action);
    double getTowerLoad4G(double currentTime);
    double getTowerLoad5G(double currentTime);
    double getMobilityTrend(MacNodeId curTower);
    double getThroughput();
    int trafficSteeringSARSA(MacNodeId nodeId, double currentTime, MacNodeId curTower, double rssi, double sinr);

    // NEW: Declaration for getAverageRSSI
    virtual double getAverageRSSI(MacNodeId nodeId, MacNodeId towerId, double currentTime);

    NearestTowerInfo findNearestTower();  // Existing declaration

    /** Master MacNodeId */
    MacNodeId masterId_;

    /** Statistic for serving cell */
    omnetpp::simsignal_t servingCell_;

    /** Self message to trigger handover procedure evaluation */
    omnetpp::cMessage *handoverStarter_;

    /** Self message to start the handover procedure */
    omnetpp::cMessage *handoverTrigger_;

    /** RSSI received from the current serving node */
    double currentMasterRssi_;

    /** ID of not-master node from which highest RSSI was received */
    MacNodeId candidateMasterId_;

    /** Highest RSSI received from not-master node */
    double candidateMasterRssi_;

    /**
     * Hysteresis threshold to evaluate handover: it introduces a small polarization to
     * avoid multiple subsequent handovers
     */
    double hysteresisTh_;

    /**
     * Value used to divide currentMasterRssi_ and create an hysteresisTh_
     * Use zero to have hysteresisTh_ == 0.
     */
    double hysteresisFactor_;

    /**
     * Time interval elapsing from the reception of first handover broadcast message
     * to the beginning of handover procedure.
     */
    double handoverDelta_;

    // time for completion of the handover procedure
    double handoverLatency_;
    double handoverDetachment_;
    double handoverAttachment_;

    // lower threshold of RSSI for detachment
    double minRssi_;

    /**
     * Handover switch
     */
    bool enableHandover_;

    /**
     * Pointer to the DAS Filter
     */
    DasFilter* das_;

    /// Threshold for antenna association
    double dasRssiThreshold_;

    /** set to false if a battery is not present */
    bool useBattery_;
    double txAmount_;    // drawn current amount for tx operations (mA)
    double rxAmount_;    // drawn current amount for rx operations (mA)

    LteMacUe *mac_;
    LteRlcUm *rlcUm_;
    LtePdcpRrcBase *pdcp_;

    omnetpp::simtime_t lastFeedback_;

    // support to print averageCqi at the end of the simulation
    std::vector<short int> cqiDlSamples_;
    std::vector<short int> cqiUlSamples_;
    unsigned int cqiDlSum_;
    unsigned int cqiUlSum_;
    unsigned int cqiDlCount_;
    unsigned int cqiUlCount_;

    // GPR section
    int predVehileX = 1, predVehileY = 1;
    int minCoorDistX = 10000, minCoorDistY = 10000;
    MacNodeId minCoorDistTowerIdX = 1, minCoorDistTowerIdY = 1;

    virtual void initialize(int stage) override;
    virtual void handleSelfMessage(omnetpp::cMessage *msg) override;
    virtual void handleAirFrame(omnetpp::cMessage* msg) override;
    virtual void finish() override;
    virtual void finish(cComponent *component, omnetpp::simsignal_t signalID) override {cIListener::finish(component, signalID);}

    virtual void handleUpperMessage(omnetpp::cMessage* msg) override;

    virtual void handleMessage(cMessage* msg) override;
    /**
     * Utility function to update the hysteresis threshold using hysteresisFactor_.
     */
    double updateHysteresisTh(double v);

    void handoverHandler(LteAirFrame* frame, UserControlInfo* lteInfo);

    void deleteOldBuffers(MacNodeId masterId);

    virtual void triggerHandover();
    virtual void doHandover();

public:
    LtePhyUe();
    virtual ~LtePhyUe();
    DasFilter *getDasFilter();
    /**
     * Send Feedback, called by feedback generator in DL
     */
    virtual void sendFeedback(LteFeedbackDoubleVector fbDl, LteFeedbackDoubleVector fbUl, FeedbackRequest req);
    MacNodeId getMasterId() const
    {
        return masterId_;
    }
    omnetpp::simtime_t coherenceTime(double speed)
    {
        double fd = (speed / SPEED_OF_LIGHT) * carrierFrequency_;
        return 0.1 / fd;
    }

    void recordCqi(unsigned int sample, Direction dir);
    double getAverageCqi(Direction dir);
    double getVarianceCqi(Direction dir);

    std::string filePath_ltePhyUe = "/home/israt/OMNETPP/ts/simu5G/src/data/";
    double calculateEachTowerLoad(int vehiclesConnectedToTower, int totalVehicles);
    void storeFileTowerLoad(const std::map<MacNodeId, std::vector<double>>& towerLoadMap, const std::string& filename);
    void performanceAnalysis();
   // void testPythonCall();
    void clearFileData(const std::string& fileName);

};

#endif  /* _LTE_AIRPHYUE_H_ */



