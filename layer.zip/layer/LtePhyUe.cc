

#include <assert.h>
#include "stack/phy/layer/LtePhyUe.h"
#include "stack/ip2nic/IP2Nic.h"
#include "stack/phy/packet/LteFeedbackPkt.h"
#include "stack/phy/feedback/LteDlFeedbackGenerator.h"
#include "inet/mobility/contract/IMobility.h"
#include "stack/phy/layer/calParameter.h"
#include <cmath>
#include <fstream>
#include <vector>
#include <set>
#include <random>

Define_Module(LtePhyUe);

calParameter* calculateParameter = new calParameter();
int count = 0;
int totalVehicles = 0;
double eachTowerLoad = 0;
std::map<MacNodeId, std::vector<double>> eachTowerLoadMap;
std::string filePath_ltePhyUe = "/home/israt/OMNETPP/ts/simu5G/src/data/";
double gprSimTime = 1;
std::map<MacNodeId, std::pair<int, int>> Tower_Position_Map;
int coordTowerX = 1, coordTowerY = 1;

bool isPerformedAnalysis_LtePhyUe = false;

int selected5G_LtePhyUe = 0, selected4G_LtePhyUe = 0;

std::vector<double> inputLSTMDataArray_tl;
std::vector<double> inputLSTMTestDataArray_tl;
double predScaValLSTM_tl;
double lstmSimTime;
std::set<int> proActTowSet;

using namespace inet;

LtePhyUe::LtePhyUe()
{
    handoverStarter_ = nullptr;
    handoverTrigger_ = nullptr;
    cqiDlSum_ = cqiUlSum_ = 0;
    cqiDlCount_ = cqiUlCount_ = 0;
    prediction_4g = 0.0;
    prediction_5g = 0.0;
    curRAT = 1;
    prevRAT = 1;
    tsDecision = 1;
    rng.seed(std::random_device{}());
}

LtePhyUe::~LtePhyUe()
{
    cancelAndDelete(handoverStarter_);
    delete das_;
    if (towerLoadFile.is_open()) towerLoadFile.close();
}

void LtePhyUe::initialize(int stage)
{
    LtePhyBase::initialize(stage);

    if (stage == inet::INITSTAGE_LOCAL)
    {
        cModule* nic = getParentModule();
        cModule* ue = nic->getParentModule();
        std::string nedType = ue->getNedTypeName();
        std::cout << "Initializing PHY for " << nedType << ", NodeId: " << nodeId_ << std::endl;
        lastLogTime = -5.0;
        predScaValLSTM_tl = 0.0;
        lstmSimTime = -1.0;

        isNr_ = false;
        nodeType_ = UE;
        useBattery_ = false;
        enableHandover_ = par("enableHandover");
        handoverLatency_ = par("handoverLatency").doubleValue();
        handoverDetachment_ = handoverLatency_ / 2.0;
        handoverAttachment_ = handoverLatency_ - handoverDetachment_;
        dynamicCellAssociation_ = par("dynamicCellAssociation");
        if (par("minRssiDefault").boolValue())
            minRssi_ = binder_->phyPisaData.minSnr();
        else
            minRssi_ = par("minRssi").doubleValue();

        currentMasterRssi_ = -999.0;
        candidateMasterRssi_ = -999.0;
        hysteresisTh_ = 0;
        hysteresisFactor_ = 10;
        handoverDelta_ = 0.00001;

        dasRssiThreshold_ = 1.0e-5;
        das_ = new DasFilter(this, binder_, nullptr, dasRssiThreshold_);

        servingCell_ = registerSignal("servingCell");
        averageCqiDl_ = registerSignal("averageCqiDl");
        averageCqiUl_ = registerSignal("averageCqiUl");

        if (!hasListeners(averageCqiDl_))
            error("no phy listeners");

        WATCH(nodeType_);
        WATCH(masterId_);
        WATCH(candidateMasterId_);
        WATCH(dasRssiThreshold_);
        WATCH(currentMasterRssi_);
        WATCH(candidateMasterRssi_);
        WATCH(hysteresisTh_);
        WATCH(hysteresisFactor_);
        WATCH(handoverDelta_);
    }
    else if (stage == inet::INITSTAGE_PHYSICAL_ENVIRONMENT)
    {
        if (useBattery_)
        {
            // TODO register the device to the battery with two accounts
        }

        txPower_ = ueTxPower_;
        lastFeedback_ = 0;
        handoverStarter_ = new cMessage("handoverStarter");

        if (isNr_)
        {
            mac_ = check_and_cast<LteMacUe *>(getParentModule()->getSubmodule("nrMac"));
            rlcUm_ = check_and_cast<LteRlcUm*>(getParentModule()->getSubmodule("nrRlc")->getSubmodule("um"));
        }
        else
        {
            mac_ = check_and_cast<LteMacUe *>(getParentModule()->getSubmodule("mac"));
            rlcUm_ = check_and_cast<LteRlcUm*>(getParentModule()->getSubmodule("rlc")->getSubmodule("um"));
        }
        pdcp_ = check_and_cast<LtePdcpRrcBase*>(getParentModule()->getSubmodule("pdcpRrc"));

        nodeId_ = isNr_ ? getAncestorPar("nrMacNodeId") : getAncestorPar("macNodeId");
        EV << "Local MacNodeId: " << nodeId_ << endl;
    }
    else if (stage == inet::INITSTAGE_PHYSICAL_LAYER)
    {
        masterId_ = isNr_ ? getAncestorPar("nrMasterId") : getAncestorPar("masterId");
        candidateMasterId_ = masterId_;

        if (dynamicCellAssociation_)
        {
            LteAirFrame *frame = new LteAirFrame("cellSelectionFrame");
            UserControlInfo *cInfo = new UserControlInfo();
            std::vector<EnbInfo*>* enbList = binder_->getEnbList();
            std::vector<EnbInfo*>::iterator it = enbList->begin();
            for (; it != enbList->end(); ++it)
            {
                if (isNr_ && (*it)->nodeType != GNODEB) continue;
                if (!isNr_ && (*it)->nodeType != ENODEB) continue;

                MacNodeId cellId = (*it)->id;
                LtePhyBase* cellPhy = check_and_cast<LtePhyBase*>((*it)->eNodeB->getSubmodule("cellularNic")->getSubmodule("phy"));
                double cellTxPower = cellPhy->getTxPwr();
                Coord cellPos = cellPhy->getCoord();

                double ueCarrierFrequency = primaryChannelModel_->getCarrierFrequency();
                LteChannelModel* cellChannelModel = cellPhy->getChannelModel(ueCarrierFrequency);
                if (cellChannelModel == nullptr) continue;

                cInfo->setSourceId(cellId);
                cInfo->setTxPower(cellTxPower);
                cInfo->setCoord(cellPos);
                cInfo->setFrameType(BROADCASTPKT);
                cInfo->setDirection(DL);

                double rssi = 0;
                std::vector<double> rssiV = primaryChannelModel_->getRSRP(frame, cInfo);
                for (auto it = rssiV.begin(); it != rssiV.end(); ++it)
                    rssi += *it;
                rssi /= rssiV.size();

                //std::cout<<"rssi cheking"<< rssi <<std::endl;

                EV << "LtePhyUe::initialize - RSSI from cell " << cellId << ": " << rssi << " dB (current candidate cell " << candidateMasterId_ << ": " << candidateMasterRssi_ << " dB)" << endl;

                if (rssi > candidateMasterRssi_)
                {
                    candidateMasterId_ = cellId;
                    candidateMasterRssi_ = rssi;
                }
            }
            delete cInfo;
            delete frame;

            if (candidateMasterId_ != 0 && candidateMasterId_ != masterId_)
            {
                binder_->unregisterNextHop(masterId_, nodeId_);
                binder_->registerNextHop(candidateMasterId_, nodeId_);
            }
            masterId_ = candidateMasterId_;
            if (isNr_)
                getAncestorPar("nrMasterId").setIntValue(masterId_);
            else
                getAncestorPar("masterId").setIntValue(masterId_);
            currentMasterRssi_ = candidateMasterRssi_;
            updateHysteresisTh(candidateMasterRssi_);
        }

        EV << "LtePhyUe::initialize - Attaching to eNodeB " << masterId_ << endl;
        das_->setMasterRuSet(masterId_);
        emit(servingCell_, (long)masterId_);
    }
    else if (stage == inet::INITSTAGE_NETWORK_CONFIGURATION)
    {
        if (masterId_ > 0)
        {
            cellInfo_ = getCellInfo(nodeId_);
            int index = intuniform(0, binder_->phyPisaData.maxChannel() - 1);
            if (cellInfo_ != NULL)
            {
                cellInfo_->lambdaInit(nodeId_, index);
                cellInfo_->channelUpdate(nodeId_, intuniform(1, binder_->phyPisaData.maxChannel2()));
            }
        }
        else
            cellInfo_ = NULL;
    }
}

void LtePhyUe::handleMessage(cMessage* msg) {
    if (simTime().dbl() >= 101.0) {
        std::cout << "Simulation time limit reached (101s), terminating..." << std::endl;
        endSimulation();
        return;
    }
    LtePhyBase::handleMessage(msg);
}

void LtePhyUe::handleSelfMessage(cMessage *msg)
{
    if (msg->isName("handoverStarter"))
        triggerHandover();
    else if (msg->isName("handoverTrigger"))
    {
        doHandover();
        delete msg;
        handoverTrigger_ = nullptr;
    }
}

void LtePhyUe::handoverHandler(LteAirFrame* frame, UserControlInfo* lteInfo)
{
    lteInfo->setDestId(nodeId_);

    if (!enableHandover_)
    {
        if (getNodeTypeById(lteInfo->getSourceId()) == ENODEB && lteInfo->getSourceId() == masterId_)
        {
            das_->receiveBroadcast(frame, lteInfo);
        }
        delete frame;
        delete lteInfo;
        return;
    }

//    // Calculate tower load
//    eachTowerLoad = calculateParameter->calculateEachTowerLoad(lteInfo, frame);
//    auto insertValue = [&](MacNodeId nodeId, double value)
//    {
//        eachTowerLoadMap[nodeId].push_back(value);
//    };
//    insertValue(lteInfo->getSourceId(), eachTowerLoad);
//
//    if ((int)simTime().dbl() % 3 == 0)
//    {
//        storeFileTowerLoad(eachTowerLoadMap, filePath_ltePhyUe + "tower_Load_test.txt");
//    }
//
//    double currentTime = simTime().dbl();
//    // LSTM call
//    static double lastLstmCallTime = -20.0;
//    if (currentTime >= lastLstmCallTime + 20.0)
//    {
//        std::cout << "Calling runLSTM() at simTime: " << currentTime << std::endl;
//        calculateParameter->runLSTM();
//        prediction_4g = 0.1;
//        prediction_5g = 0.1;
//
//        std::ifstream inFile4g(filePath_ltePhyUe + "outputLSTM_4G.txt");
//        if (inFile4g.is_open())
//        {
//            std::string line;
//            if (std::getline(inFile4g, line))
//            {
//                prediction_4g = std::stod(line);
//            }
//            inFile4g.close();
//        }
//
//        std::ifstream inFile5g(filePath_ltePhyUe + "outputLSTM_5G.txt");
//        if (inFile5g.is_open())
//        {
//            std::string line;
//            if (std::getline(inFile5g, line))
//            {
//                prediction_5g = std::stod(line);
//            }
//            inFile5g.close();
//        }
//
//        std::cout << "LSTM Predictions - 4G: " << prediction_4g << ", 5G: " << prediction_5g << std::endl;
//        lastLstmCallTime = currentTime;
//    }


    MacNodeId sourceId = lteInfo->getSourceId();
       std::cout << "Handover - Tower: " << sourceId << " at simTime: " << omnetpp::simTime().dbl() << std::endl;
       eachTowerLoad = calculateParameter->calculateEachTowerLoad(lteInfo, frame);
       auto insertValue = [&](MacNodeId nodeId, double value) {
           eachTowerLoadMap[nodeId].push_back(value);
       };
       insertValue(sourceId, eachTowerLoad);

       double currentTime = omnetpp::simTime().dbl();
       static double lastLstmCallTime = -20.0;
       static double lastLoad = 0.0;
       double loadChange = std::abs(eachTowerLoad - lastLoad);
       const double initialDelay = 10.0;

       if (currentTime < initialDelay) {
           std::cout << "Skipping runLSTM() to collect data, simTime: " << currentTime << std::endl;
       } else if (currentTime >= lastLstmCallTime + 10.0 ) {
           std::cout << "Calling runLSTM() at simTime: " << currentTime
                     << ", loadChange: " << loadChange << ", eachTowerLoad: " << eachTowerLoad << std::endl;
           calculateParameter->runLSTM();
           prediction_4g = calculateParameter->getPrediction4G();
           prediction_5g = calculateParameter->getPrediction5G();
           std::cout << "LSTM Predictions - 4G: " << prediction_4g << ", 5G: " << prediction_5g
                     << " at simTime: " << currentTime << std::endl;
           lastLstmCallTime = currentTime;
           lastLoad = eachTowerLoad;
       }


//    // Existing code...
//    eachTowerLoad = calculateParameter->calculateEachTowerLoad(lteInfo, frame);
//        auto insertValue = [&](MacNodeId nodeId, double value) {
//            eachTowerLoadMap[nodeId].push_back(value);
//        };
//        insertValue(lteInfo->getSourceId(), eachTowerLoad);
//
//        double currentTime = simTime().dbl();
//        static double lastLstmCallTime = -20.0;
//        static double lastLoad = 0.0;
//        double loadChange = std::abs(eachTowerLoad - lastLoad);
//        // Force call for debugging or use adaptive condition
//        if (currentTime >= lastLstmCallTime + 20.0 /* && loadChange > 0.05 */) {
//            std::cout << "Calling runLSTM() at simTime: " << currentTime
//                      << ", loadChange: " << loadChange << ", eachTowerLoad: " << eachTowerLoad << std::endl;
//            calculateParameter->runLSTM();
//            prediction_4g = calculateParameter->getPrediction4G();
//            prediction_5g = calculateParameter->getPrediction5G();
//            std::cout << "LSTM Predictions - 4G: " << prediction_4g << ", 5G: " << prediction_5g
//                      << " at simTime: " << currentTime << std::endl;
//            lastLstmCallTime = currentTime;
//            lastLoad = eachTowerLoad;
//        }

    // Compute RSSI
    frame->setControlInfo(lteInfo);
    double rssi;
    if (getNodeTypeById(lteInfo->getSourceId()) == ENODEB && lteInfo->getSourceId() == masterId_)
    {
        rssi = das_->receiveBroadcast(frame, lteInfo);
    }
    else
    {
        std::vector<double> rssiV = primaryChannelModel_->getSINR(frame, lteInfo);
        rssi = std::accumulate(rssiV.begin(), rssiV.end(), 0.0) / rssiV.size();
    }

    // Compute SINR
    double sinr = 0.0;
    std::vector<double> sinrV = primaryChannelModel_->getSINR(frame, lteInfo);
    if (!sinrV.empty()) {
        sinr = *std::max_element(sinrV.begin(), sinrV.end());
    }

    // Store RSSI in memory
    rssiHistory.push_back({currentTime, nodeId_, lteInfo->getSourceId(), rssi});
    if (rssiHistory.size() > 100) rssiHistory.erase(rssiHistory.begin()); // Limit history size

    // Store tower load for SARSA
    TowerLoadEntry loadEntry = {currentTime, lteInfo->getSourceId(), (lteInfo->getSourceId() > 2), eachTowerLoad};
    towerLoadData.push_back(loadEntry);
    if (towerLoadData.size() > 100) towerLoadData.erase(towerLoadData.begin());

    // Update Tower_Position_Map for GPR
    coordTowerX = (int)lteInfo->getCoord().x;
    coordTowerY = (int)lteInfo->getCoord().y;
    Tower_Position_Map[lteInfo->getSourceId()] = std::make_pair(coordTowerX, coordTowerY);

    // SARSA for traffic steering
    static double lastSarsaTime = -10.0;
    if (currentTime >= lastSarsaTime + 10.0)
    {
        int rat = trafficSteeringSARSA(nodeId_, currentTime, lteInfo->getSourceId(), rssi, sinr);
        tsDecision = (rat == 0) ? 0 : (rat == 1) ? 1 : curRAT;
        std::ofstream tsFile(filePath_ltePhyUe + "tsDecision.txt", std::ios::app);
        if (tsFile.is_open()) {
            tsFile << currentTime << "," << nodeId_ << "," << tsDecision << "\n";
            tsFile.close();
        }
        if (tsDecision == 0) {
            selected5G_LtePhyUe++;
            curRAT = 0;
            if (lteInfo->getSourceId() <= 2) candidateMasterId_ = 3; // Example 5G tower
            std::cout << "Node " << nodeId_ << ": SARSA chose 5G" << std::endl;
        } else if (tsDecision == 1) {
            selected4G_LtePhyUe++;
            curRAT = 1;
            if (lteInfo->getSourceId() > 2) candidateMasterId_ = 1; // Example 4G tower
            std::cout << "Node " << nodeId_ << ": SARSA chose 4G" << std::endl;
        }
        lastSarsaTime = currentTime;
    }

    // Update RAT switching
    if (curRAT != prevRAT) {
        prevRAT = curRAT;
    }

    // Existing handover logic
    storeRSSIToFile(nodeId_, lteInfo->getSourceId(), rssi);
    redirectToNetwork(nodeId_, lteInfo->getSourceId(), rssi);

    if (lteInfo->getSourceId() != masterId_ && rssi < minRssi_)
    {
        EV << "Signal too weak from a candidate master - minRssi[" << minRssi_ << "]" << endl;
        delete frame;
        return;
    }

    if (rssi > candidateMasterRssi_ + hysteresisTh_)
    {
        if (lteInfo->getSourceId() == masterId_)
        {
            currentMasterRssi_ = rssi;
            candidateMasterId_ = masterId_;
            candidateMasterRssi_ = rssi;
            hysteresisTh_ = updateHysteresisTh(currentMasterRssi_);
            cancelEvent(handoverStarter_);
        }
        else
        {
            candidateMasterId_ = lteInfo->getSourceId();
            candidateMasterRssi_ = rssi;
            hysteresisTh_ = updateHysteresisTh(rssi);
            binder_->addHandoverTriggered(nodeId_, masterId_, candidateMasterId_);

            if (!handoverStarter_->isScheduled())
            {
                scheduleAt(simTime() + handoverDelta_, handoverStarter_);
            }
        }
    }
    else
    {
        if (lteInfo->getSourceId() == masterId_)
        {
            if (rssi >= minRssi_)
            {
                currentMasterRssi_ = rssi;
                candidateMasterRssi_ = rssi;
                hysteresisTh_ = updateHysteresisTh(rssi);
            }
            else
            {
                if (candidateMasterId_ == masterId_)
                {
                    candidateMasterId_ = 0;
                    candidateMasterRssi_ = 0;
                    hysteresisTh_ = updateHysteresisTh(0);
                    binder_->addHandoverTriggered(nodeId_, masterId_, candidateMasterId_);

                    if (!handoverStarter_->isScheduled())
                    {
                        scheduleAt(simTime() + handoverDelta_, handoverStarter_);
                    }
                }
            }
        }
    }

    delete frame;
}

double LtePhyUe::calculateEachTowerLoad(int vehiclesConnectedToTower, int totalVehicles) {
    if (totalVehicles > 0) {
        return static_cast<double>(vehiclesConnectedToTower) / totalVehicles * 100.0;
    } else {
        std::cerr << "Error: Total number of vehicles is zero." << std::endl;
        return -1.0;
    }
}

void LtePhyUe::clearFileData(const std::string& fileName)
{
    std::ofstream file(filePath_ltePhyUe + fileName, std::ofstream::trunc);
    file.close();
}

void LtePhyUe::triggerHandover()
{
    ASSERT(masterId_ != candidateMasterId_);

    EV << "####Handover starting:####" << endl;
    EV << "current master: " << masterId_ << endl;
    EV << "current rssi: " << currentMasterRssi_ << endl;
    EV << "candidate master: " << candidateMasterId_ << endl;
    EV << "candidate rssi: " << candidateMasterRssi_ << endl;
    EV << "############" << endl;

    if (candidateMasterRssi_ == 0)
        EV << NOW << " LtePhyUe::triggerHandover - UE " << nodeId_ << " lost its connection to eNB " << masterId_ << ". Now detaching... " << endl;
    else if (masterId_ == 0)
        EV << NOW << " LtePhyUe::triggerHandover - UE " << nodeId_ << " is starting attachment procedure to eNB " << candidateMasterId_ << "... " << endl;
    else
        EV << NOW << " LtePhyUe::triggerHandover - UE " << nodeId_ << " is starting handover to eNB " << candidateMasterId_ << "... " << endl;

    binder_->addUeHandoverTriggered(nodeId_);

    IP2Nic* ip2nic = check_and_cast<IP2Nic*>(getParentModule()->getSubmodule("ip2nic"));
    ip2nic->triggerHandoverUe(candidateMasterId_);
    binder_->removeHandoverTriggered(nodeId_);

    if (masterId_ != 0 && candidateMasterId_ != 0)
    {
        IP2Nic* enbIp2Nic = check_and_cast<IP2Nic*>(getSimulation()->getModule(binder_->getOmnetId(masterId_))->getSubmodule("cellularNic")->getSubmodule("ip2nic"));
        enbIp2Nic->triggerHandoverSource(nodeId_, candidateMasterId_);
    }

    double handoverLatency;
    if (masterId_ == 0)
        handoverLatency = handoverAttachment_;
    else if (candidateMasterId_ == 0)
        handoverLatency = handoverDetachment_;
    else
        handoverLatency = handoverDetachment_ + handoverAttachment_;

    handoverTrigger_ = new cMessage("handoverTrigger");
    scheduleAt(simTime() + handoverLatency, handoverTrigger_);
}

void LtePhyUe::doHandover()
{
    if (masterId_ != 0)
    {
        deleteOldBuffers(masterId_);
        LteAmc *oldAmc = getAmcModule(masterId_);
        oldAmc->detachUser(nodeId_, UL);
        oldAmc->detachUser(nodeId_, DL);
    }

    if (candidateMasterId_ != 0)
    {
        LteAmc *newAmc = getAmcModule(candidateMasterId_);
        assert(newAmc != nullptr);
        newAmc->attachUser(nodeId_, UL);
        newAmc->attachUser(nodeId_, DL);
    }

    if (masterId_ != 0)
        binder_->unregisterNextHop(masterId_, nodeId_);

    if (candidateMasterId_ != 0)
    {
        binder_->registerNextHop(candidateMasterId_, nodeId_);
        das_->setMasterRuSet(candidateMasterId_);
    }
    binder_->updateUeInfoCellId(nodeId_, candidateMasterId_);

    if (getParentModule()->getParentModule()->findSubmodule("ueCollector") != -1)
    {
        binder_->moveUeCollector(nodeId_, masterId_, candidateMasterId_);
    }

    MacNodeId oldMaster = masterId_;
    masterId_ = candidateMasterId_;
    mac_->doHandover(candidateMasterId_);
    currentMasterRssi_ = candidateMasterRssi_;
    hysteresisTh_ = updateHysteresisTh(currentMasterRssi_);

    if (masterId_ != 0)
        cellInfo_->detachUser(nodeId_);

    if (candidateMasterId_ != 0)
    {
        CellInfo* oldCellInfo = cellInfo_;
        LteMacEnb* newMacEnb = check_and_cast<LteMacEnb*>(getSimulation()->getModule(binder_->getOmnetId(candidateMasterId_))->getSubmodule("cellularNic")->getSubmodule("mac"));
        CellInfo* newCellInfo = newMacEnb->getCellInfo();
        newCellInfo->attachUser(nodeId_);
        cellInfo_ = newCellInfo;
        if (oldCellInfo == NULL)
        {
            int index = intuniform(0, binder_->phyPisaData.maxChannel() - 1);
            cellInfo_->lambdaInit(nodeId_, index);
            cellInfo_->channelUpdate(nodeId_, intuniform(1, binder_->phyPisaData.maxChannel2()));
        }
    }

    LteDlFeedbackGenerator* fbGen = check_and_cast<LteDlFeedbackGenerator*>(getParentModule()->getSubmodule("dlFbGen"));
    fbGen->handleHandover(masterId_);

    emit(servingCell_, (long)masterId_);

    if (masterId_ == 0)
        EV << NOW << " LtePhyUe::doHandover - UE " << nodeId_ << " detached from the network" << endl;
    else
        EV << NOW << " LtePhyUe::doHandover - UE " << nodeId_ << " has completed handover to eNB " << masterId_ << "... " << endl;

    binder_->removeUeHandoverTriggered(nodeId_);

    IP2Nic* ip2nic = check_and_cast<IP2Nic*>(getParentModule()->getSubmodule("ip2nic"));
    ip2nic->signalHandoverCompleteUe();

    if (oldMaster != 0 && candidateMasterId_ != 0)
    {
        IP2Nic* enbIp2Nic = check_and_cast<IP2Nic*>(getSimulation()->getModule(binder_->getOmnetId(masterId_))->getSubmodule("cellularNic")->getSubmodule("ip2nic"));
        enbIp2Nic->signalHandoverCompleteTarget(nodeId_, oldMaster);
    }
}

void LtePhyUe::handleAirFrame(cMessage* msg)
{
    UserControlInfo* lteInfo = dynamic_cast<UserControlInfo*>(msg->removeControlInfo());

    if (useBattery_)
    {
        //TODO BatteryAccess::drawCurrent(rxAmount_, 0);
    }
    connectedNodeId_ = masterId_;
    LteAirFrame* frame = check_and_cast<LteAirFrame*>(msg);
    EV << "LtePhy: received new LteAirFrame with ID " << frame->getId() << " from channel" << endl;

    int sourceId = binder_->getOmnetId(lteInfo->getSourceId());
    if (sourceId == 0)
    {
        delete msg;
        return;
    }

    double carrierFreq = lteInfo->getCarrierFrequency();
    LteChannelModel* channelModel = getChannelModel(carrierFreq);
    if (channelModel == NULL)
    {
        EV << "Received packet on unsupported carrier frequency. Delete it." << endl;
        delete lteInfo;
        delete frame;
        return;
    }

    if (lteInfo->getFrameType() == HANDOVERPKT)
    {
        if (carrierFreq != primaryChannelModel_->getCarrierFrequency() || (handoverTrigger_ != nullptr && handoverTrigger_->isScheduled()))
        {
            EV << "Received handover packet on a different carrier frequency than the primary cell. Delete it." << endl;
            delete lteInfo;
            delete frame;
            return;
        }

        handoverHandler(frame, lteInfo);
        return;
    }

    if (lteInfo->getDestId() != nodeId_)
    {
        EV << "ERROR: Frame is not for us. Delete it." << endl;
        delete lteInfo;
        delete frame;
        return;
    }

    if (lteInfo->getSourceId() != masterId_)
    {
        EV << "WARNING: frame from an old master during handover: deleted " << endl;
        delete frame;
        return;
    }

    if (lteInfo->getFrameType() == HARQPKT || lteInfo->getFrameType() == GRANTPKT || lteInfo->getFrameType() == RACPKT)
    {
        handleControlMsg(frame, lteInfo);
        return;
    }

    if ((lteInfo->getUserTxParams()) != nullptr)
    {
        int cw = lteInfo->getCw();
        if (lteInfo->getUserTxParams()->readCqiVector().size() == 1)
            cw = 0;
        double cqi = lteInfo->getUserTxParams()->readCqiVector()[cw];
        emit(averageCqiDl_, cqi);
        recordCqi(cqi, DL);
    }

    bool result = true;
    RemoteSet r = lteInfo->getUserTxParams()->readAntennaSet();
    if (r.size() > 1)
    {
        for (RemoteSet::iterator it = r.begin(); it != r.end(); it++)
        {
            RemoteUnitPhyData data;
            data.txPower = lteInfo->getTxPower();
            data.m = getRadioPosition();
            frame->addRemoteUnitPhyDataVector(data);
        }
        result = channelModel->isErrorDas(frame, lteInfo);
    }
    else
    {
        result = channelModel->isError(frame, lteInfo);
    }

    if (result)
        numAirFrameReceived_++;
    else
        numAirFrameNotReceived_++;

    EV << "Handled LteAirframe with ID " << frame->getId() << " with result " << (result ? "RECEIVED" : "NOT RECEIVED") << endl;

    auto pkt = check_and_cast<inet::Packet *>(frame->decapsulate());
    delete frame;

    lteInfo->setDeciderResult(result);
    *(pkt->addTagIfAbsent<UserControlInfo>()) = *lteInfo;
    delete lteInfo;

    send(pkt, upperGateOut_);

    if (getEnvir()->isGUI())
        updateDisplayString();
}

void LtePhyUe::handleUpperMessage(cMessage* msg)
{
    auto pkt = check_and_cast<inet::Packet *>(msg);
    auto lteInfo = pkt->getTag<UserControlInfo>();

    MacNodeId dest = lteInfo->getDestId();
    if (dest != masterId_)
    {
        throw cRuntimeError("LtePhyUe::handleUpperMessage  Ue preparing to send message to %d instead of its master (%d)", dest, masterId_);
    }

    double carrierFreq = lteInfo->getCarrierFrequency();
    LteChannelModel* channelModel = getChannelModel(carrierFreq);
    if (channelModel == NULL)
        throw cRuntimeError("LtePhyUe::handleUpperMessage - Carrier frequency [%f] not supported by any channel model", carrierFreq);

    if (lteInfo->getFrameType() == DATAPKT && (channelModel->isUplinkInterferenceEnabled() || channelModel->isD2DInterferenceEnabled()))
    {
        RbMap rbMap = lteInfo->getGrantedBlocks();
        Remote antenna = MACRO;
        binder_->storeUlTransmissionMap(channelModel->getCarrierFrequency(), antenna, rbMap, nodeId_, mac_->getMacCellId(), this, UL);
    }

    if (lteInfo->getFrameType() == DATAPKT && lteInfo->getUserTxParams() != nullptr)
    {
        double cqi = lteInfo->getUserTxParams()->readCqiVector()[lteInfo->getCw()];
        if (lteInfo->getDirection() == UL)
        {
            emit(averageCqiUl_, cqi);
            recordCqi(cqi, UL);
        }
        else if (lteInfo->getDirection() == D2D)
            emit(averageCqiD2D_, cqi);
    }

    LtePhyBase::handleUpperMessage(msg);
}

double LtePhyUe::updateHysteresisTh(double v)
{
    if (hysteresisFactor_ == 0)
        return 0;
    else
        return v / hysteresisFactor_;
}

void LtePhyUe::deleteOldBuffers(MacNodeId masterId)
{
    LteMacEnb *masterMac = check_and_cast<LteMacEnb *>(getMacByMacNodeId(masterId));
    masterMac->deleteQueues(nodeId_);

    mac_->deleteQueues(masterId_);

    LteRlcUm *masterRlcUm = check_and_cast<LteRlcUm*>(getRlcByMacNodeId(masterId, UM));
    masterRlcUm->deleteQueues(nodeId_);

    rlcUm_->deleteQueues(nodeId_);

    LtePdcpRrcEnb* masterPdcp = check_and_cast<LtePdcpRrcEnb *>(getPdcpByMacNodeId(masterId));
    masterPdcp->deleteEntities(nodeId_);

    pdcp_->deleteEntities(masterId_);
}

DasFilter* LtePhyUe::getDasFilter()
{
    return das_;
}

void LtePhyUe::sendFeedback(LteFeedbackDoubleVector fbDl, LteFeedbackDoubleVector fbUl, FeedbackRequest req)
{
    Enter_Method("SendFeedback");
    EV << "LtePhyUe: feedback from Feedback Generator" << endl;

    auto fbPkt = makeShared<LteFeedbackPkt>();
    fbPkt->setLteFeedbackDoubleVectorDl(fbDl);
    fbPkt->setLteFeedbackDoubleVectorUl(fbUl);
    fbPkt->setSourceNodeId(nodeId_);

    auto pkt = new Packet("feedback_pkt");
    pkt->insertAtFront(fbPkt);

    UserControlInfo* uinfo = new UserControlInfo();
    uinfo->setSourceId(nodeId_);
    uinfo->setDestId(masterId_);
    uinfo->setFrameType(FEEDBACKPKT);
    uinfo->setIsCorruptible(false);

    LteAirFrame* frame = new LteAirFrame("feedback_pkt");
    frame->encapsulate(check_and_cast<cPacket*>(pkt));
    uinfo->feedbackReq = req;
    uinfo->setDirection(UL);
    simtime_t signalLength = TTI;
    uinfo->setTxPower(txPower_);

    frame->setSchedulingPriority(airFramePriority_);
    frame->setDuration(signalLength);
    uinfo->setCoord(getRadioPosition());

    lastFeedback_ = NOW;

    std::map<double, LteChannelModel*>::iterator cit = channelModel_.begin();
    for (; cit != channelModel_.end(); ++cit)
    {
        double carrierFrequency = cit->first;
        LteAirFrame* carrierFrame = frame->dup();
        UserControlInfo* carrierInfo = uinfo->dup();
        carrierInfo->setCarrierFrequency(carrierFrequency);
        carrierFrame->setControlInfo(carrierInfo);

        EV << "LtePhy: sending feedback to the air channel for carrier " << carrierFrequency << endl;
        sendUnicast(carrierFrame);
    }

    delete frame;
    delete uinfo;
}

void LtePhyUe::recordCqi(unsigned int sample, Direction dir)
{
    if (dir == DL)
    {
        cqiDlSamples_.push_back(sample);
        cqiDlSum_ += sample;
        cqiDlCount_++;
    }
    if (dir == UL)
    {
        cqiUlSamples_.push_back(sample);
        cqiUlSum_ += sample;
        cqiUlCount_++;
    }
}

double LtePhyUe::getAverageCqi(Direction dir)
{
    if (dir == DL)
    {
        if (cqiDlCount_ == 0) return 0;
        return (double)cqiDlSum_ / cqiDlCount_;
    }
    if (dir == UL)
    {
        if (cqiUlCount_ == 0) return 0;
        return (double)cqiUlSum_ / cqiUlCount_;
    }
    throw cRuntimeError("Direction %d is not handled.", dir);
}

double LtePhyUe::getVarianceCqi(Direction dir)
{
    double avgCqi = getAverageCqi(dir);
    double err, sum = 0;

    if (dir == DL)
    {
        for (auto it = cqiDlSamples_.begin(); it != cqiDlSamples_.end(); ++it)
        {
            err = avgCqi - *it;
            sum += (err * err);
        }
        return sum / cqiDlSamples_.size();
    }
    if (dir == UL)
    {
        for (auto it = cqiUlSamples_.begin(); it != cqiUlSamples_.end(); ++it)
        {
            err = avgCqi - *it;
            sum += (err * err);
        }
        return sum / cqiUlSamples_.size();
    }
    throw cRuntimeError("Direction %d is not handled.", dir);
}

void LtePhyUe::finish()
{
    if (getSimulation()->getSimulationStage() != CTX_FINISH)
    {
        if (masterId_ > 0)
        {
            deleteOldBuffers(masterId_);
            LteAmc *amc = getAmcModule(masterId_);
            if (amc != nullptr)
            {
                amc->detachUser(nodeId_, UL);
                amc->detachUser(nodeId_, DL);
            }
            binder_->unregisterNextHop(masterId_, nodeId_);
            cellInfo_->detachUser(nodeId_);
        }
    }
}

//void LtePhyUe::testPythonCall() {
//    double currentTime = simTime().dbl();
//    if (currentTime >= lastLstmCallTime + 30.0) {
//        std::cout << "Running LSTM prediction at simTime: " << currentTime << std::endl;
//        calculateParameter->runLSTM();
//
//        std::ifstream inFile4g("/home/israt/OMNETPP/ts/simu5G/src/data/outputLSTM_4G.txt");
//        if (inFile4g.is_open()) {
//            std::string line;
//            if (std::getline(inFile4g, line)) prediction_4g = std::stod(line);
//            inFile4g.close();
//        }
//
//        std::ifstream inFile5g("/home/israt/OMNETPP/ts/simu5G/src/data/outputLSTM_5G.txt");
//        if (inFile5g.is_open()) {
//            std::string line;
//            if (std::getline(inFile5g, line)) prediction_5g = std::stod(line);
//            inFile5g.close();
//        }
//
//        std::cout << "Predictions - 4G: " << prediction_4g << ", 5G: " << prediction_5g << std::endl;
//        lastLstmCallTime = currentTime;
//
//        std::ofstream actualFile("/home/israt/OMNETPP/ts/simu5G/src/data/actualLoads.txt", std::ios::app);
//        if (actualFile.is_open()) {
//            for (const auto& pair : eachTowerLoadMap) {
//                if (!pair.second.empty()) {
//                    double latestLoad = pair.second.back();
//                    actualFile << currentTime << "," << pair.first << ","
//                               << (pair.first <= 2 ? 0 : 1) << "," << latestLoad << "\n";
//                }
//            }
//            actualFile.close();
//        }
//    }
//
//    if (currentTime >= 30.0 && fmod(currentTime, 30.0) < 0.001) {
//        eachTowerLoadMap.clear();
//        Tower_Position_Map.clear();
//        for (int i = 0; i < 4; i++) calculateParameter->bsLoad[i] = 0;
//        std::cout << "Memory cleared at simTime: " << currentTime << std::endl;
//
//        std::ofstream towerFile("/home/israt/OMNETPP/ts/simu5G/src/data/towerLoadData.txt", std::ios::trunc);
//        if (towerFile.is_open()) towerFile.close();
//    }
//}

void LtePhyUe::storeRSSIToFile(int nodeId, int towerId, double rssi) {
    std::string filePath = "/home/israt/OMNETPP/ts/simu5G/src/data/rssiData.txt";
    std::ofstream outFile(filePath, std::ios::app);
    if (outFile.is_open()) {
        outFile << "Time: " << simTime()
                << ", NodeId: " << nodeId
                << ", TowerId: " << towerId
                << ", RSSI: " << rssi
                << std::endl;
        outFile.close();
    } else {
        EV << "Unable to open file for writing RSSI data." << endl;
    }
}

void LtePhyUe::redirectToNetwork(int nodeId, int towerId, double rssi) {
    if (rssi > 14) {
        EV << "Node " << nodeId << " redirected to 5G tower " << towerId << endl;
    } else {
        EV << "Node " << nodeId << " redirected to 4G tower " << towerId << endl;
    }
}

void LtePhyUe::storeFileTowerLoad(const std::map<MacNodeId, std::vector<double>>& towerLoadMap, const std::string& filename)
{
    std::ofstream outFile(filename, std::ios_base::app);
    if (outFile.is_open()) {
        double currentTime = simTime().dbl();
        std::cout<< "currentTime " <<currentTime <<std::endl;
        for (const auto& pair : towerLoadMap) {
            for (double val : pair.second) {
                outFile << currentTime << ","
                        << pair.first << ","
                        << (pair.first <= 2 ? 0 : 1) << ","
                        << val << "\n";
            }
        }
        outFile.close();
        eachTowerLoadMap.clear();
    }
}

NearestTowerInfo LtePhyUe::findNearestTower() {
    NearestTowerInfo result = {0, 0, INT_MAX, INT_MAX, 0, std::numeric_limits<double>::max(), false};

    if (Tower_Position_Map.empty()) {
        std::cout << "No towers in Tower_Position_Map" << std::endl;
        return result;
    }

    for (const auto& pair : Tower_Position_Map) {
        double dx = pair.second.first - predVehileX;
        double dy = pair.second.second - predVehileY;
        double dist = sqrt(dx * dx + dy * dy);
        if (dist < result.minDist) {
            result.minDist = dist;
            result.closestTower = pair.first;
            result.is5G = (pair.first > 2);
        }
    }

    std::cout << "Nearest Tower ID: " << result.closestTower << " (Dist: " << result.minDist
              << ", Type: " << (result.is5G ? "5G" : "4G") << ")" << std::endl;
    return result;
}

// New function to compute average RSSI from history
double LtePhyUe::getAverageRSSI(MacNodeId nodeId, MacNodeId towerId, double currentTime) {
    double sum = 0.0;
    int count = 0;
    for (const auto& entry : rssiHistory) {
        if (entry.nodeId == nodeId && entry.towerId == towerId &&
            entry.time > currentTime - 5.0) { // Last 5 seconds
            sum += entry.rssi;
            count++;
        }
    }
    return count > 0 ? sum / count : 0.0; // Return 0 if no data
}

int LtePhyUe::selectRATAction(int state, double epsilon) {
    if ((double)rand() / RAND_MAX < epsilon) {
        return rand() % 2;
    }
    auto Q = Q_per_vehicle[nodeId_];
    double q_stay = Q[{state, 0}];
    double q_switch = Q[{state, 1}];
    return (q_stay >= q_switch) ? 0 : 1;
}

int LtePhyUe::getNextState(int state, int action) {
    if (action == 0) return state;
    return 1 - state;
}

double LtePhyUe::getTowerLoad4G(double currentTime) {
    double sum = 0.0;
    int count = 0;
    for (const auto& entry : towerLoadData) {
        if (entry.time <= currentTime && entry.time > currentTime - 3.0 && !entry.is5G) {
            sum += entry.load;
            count++;
        }
    }
    return (count > 0) ? sum / count / 100.0 : prediction_4g;
}

double LtePhyUe::getTowerLoad5G(double currentTime) {
    double sum = 0.0;
    int count = 0;
    for (const auto& entry : towerLoadData) {
        if (entry.time <= currentTime && entry.time > currentTime - 3.0 && entry.is5G) {
            sum += entry.load;
            count++;
        }
    }
    return (count > 0) ? sum / count / 100.0 : prediction_5g;
}

double LtePhyUe::getMobilityTrend(MacNodeId curTower) {
    NearestTowerInfo nearest = findNearestTower();
    return nearest.is5G ? 0.75 : 0.25;
}

/*double LtePhyUe::getThroughput() {
    return 80.0;
}*/
double LtePhyUe::getThroughput() {
    std::ifstream infile("/home/israt/OMNETPP/ts/simu5G/src/data/throughput.txt");
    double throughput = 0.0;

    if (infile.is_open()) {
        infile >> throughput; // Read first value from the file
        infile.close();
    } else {
        EV << "Error: Could not open throughput.txt" << endl;
        throughput = 80.0; // fallback default
    }

    return  throughput;
}

int LtePhyUe::trafficSteeringSARSA(MacNodeId nodeId, double currentTime, MacNodeId curTower, double rssi, double sinr) {
    const double epsilonSarsa = 0.1;
    const int MAX_EPISODES = 5;
    const int MAX_ITERATIONS = 5;
    const double ALPHA = 0.1;
    const double GAMMA = 0.9; // Fixed: Replaced 'Etherium' with 'GAMMA'
    double w_throughput = 0.3, w_rssi = 0.25, w_sinr = 0.2, w_Lt = -0.15, w_Mt = 0.1;

    // Use average RSSI from history instead of instantaneous rssi
  //  double avg_rssi = getAverageRSSI(nodeId, curTower, currentTime);
   // if (avg_rssi == 0.0) avg_rssi = rssi; // Fallback to instantaneous rssi if no history

    for (int episode = 0; episode < MAX_EPISODES; episode++) {
        int state = (curTower > 2) ? 0 : 1;
        for (int iter = 0; iter < MAX_ITERATIONS; iter++) {
            int action = selectRATAction(state, epsilonSarsa);
            int nextState = getNextState(state, action);

            double Lt_4G = getTowerLoad4G(currentTime);
            double Lt_5G = getTowerLoad5G(currentTime);
            double Mt = getMobilityTrend(curTower);
            double throughput = getThroughput();
            double norm_throughput = throughput / 150.0;
            double norm_rssi = (rssi + 100.0) / 200.0; // Use avg_rssi
            double norm_sinr = sinr / 30.0;
            double norm_Lt = (state == 0) ? Lt_5G : Lt_4G;
            double norm_Mt = Mt;
            double Mt_bonus = (state == 0 && Mt > 0.5) ? 0.1 : ((state == 1 && Mt <= 0.5) ? 0.1 : -0.1);

            double reward = (w_throughput * norm_throughput) +
                           (w_rssi * norm_rssi) +
                           (w_sinr * norm_sinr) +
                           (w_Lt * norm_Lt) +
                           (w_Mt * norm_Mt) +
                           Mt_bonus;

            int nextAction = selectRATAction(nextState, epsilonSarsa);
            double q_next = Q_per_vehicle[nodeId][{nextState, nextAction}];
            Q_per_vehicle[nodeId][{state, action}] += ALPHA * (reward + GAMMA * q_next - Q_per_vehicle[nodeId][{state, action}]); // Fixed: Use GAMMA

            state = nextState;
        }
    }

    auto Q = Q_per_vehicle[nodeId];
    double max_5g = std::max(Q[{0, 0}], Q[{0, 1}]);
    double max_4g = std::max(Q[{1, 0}], Q[{1, 1}]);
    if (max_5g > max_4g) return 0;
    if (max_4g > max_5g) return 1;
    return -1;
}

void LtePhyUe::performanceAnalysis()
{
    if (simTime().dbl() > 100 && !isPerformedAnalysis_LtePhyUe)
    {
        int totalSelections = selected5G_LtePhyUe + selected4G_LtePhyUe;
        double percentage5G = (totalSelections > 0) ? (static_cast<double>(selected5G_LtePhyUe) / totalSelections) * 100 : 0;
        double percentage4G = (totalSelections > 0) ? (static_cast<double>(selected4G_LtePhyUe) / totalSelections) * 100 : 0;

        std::cout << "End Simtime: " << simTime().dbl() << std::endl;
        std::cout << "Selected 5G RAT: " << selected5G_LtePhyUe << " (" << percentage5G << "%)" << std::endl;
        std::cout << "Selected 4G RAT: " << selected4G_LtePhyUe << " (" << percentage4G << "%)" << std::endl;

        int result;
        time_t t = time(0);
        struct tm *now = localtime(&t);
        char buffer[80];
        strftime(buffer, 80, "%Y%m%d%H%M%S", now);
        char oldname[] = "/home/israt/OMNETPP/omnetpp60/Results_CMD/outputCMD.txt";
        std::string str(buffer);
        std::string strNewFile = "/home/israt/OMNETPP/omnetpp60/Results_CMD/" + str + ".txt";
        int len = strNewFile.length();
        char buffer_new[len + 1];
        strcpy(buffer_new, strNewFile.c_str());
        result = rename(oldname, buffer_new);

        isPerformedAnalysis_LtePhyUe = true;
    }
}

